﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1.Suporte
{
    public class FileSystemOperation
    {
        public List<string> ListFolders(string rootFolder)
        {
            List<string> pastas = new();

            try
            {
                string fullPath = Path.GetFullPath(rootFolder);
                List<string> dirs = new(Directory.GetDirectories(fullPath, "*", SearchOption.AllDirectories));

                foreach (string dir in dirs)
                {
                    DirectoryInfo dirInfo = new(dir);
                    pastas.Add($"{dirInfo.Name} / {dirInfo.CreationTime}");
                }

                return pastas;
            }
            catch (Exception)
            {
                throw;
            }
        }

        public List<string> ListFiles(string rootFolder)
        {
            List<string> arquivos = new();

            try
            {
                string fullPath = Path.GetFullPath(rootFolder);
                List<string> files = new(Directory.GetFiles(fullPath, "*", SearchOption.AllDirectories));

                foreach (string file in files)
                {
                    FileInfo fileInfo = new(file);
                    arquivos.Add($"{fileInfo.Name} / {fileInfo.CreationTime}");
                }

                return arquivos;
            }
            catch (Exception)
            {
                throw;
            }
        }

        public List<string> ListFiles(string rootFolder, string pattern)
        {
            List<string> arquivos = new();

            try
            {
                string fullPath = Path.GetFullPath(rootFolder);
                List<string> files = new(Directory.GetFiles(fullPath, pattern, SearchOption.AllDirectories));

                foreach (string file in files)
                {
                    FileInfo fileInfo = new(file);
                    arquivos.Add($"{fileInfo.Name} / {fileInfo.CreationTime}");
                }

                return arquivos;
            }
            catch (Exception)
            {
                throw;
            }
        }

        public bool CopyFile(string origem, string destino)
        {
            bool result = false;

            if (File.Exists(origem))
            {
                File.Copy(origem, destino);
                result = true;
            }

            return result;
        }

        public bool DeleteFile(string origem)
        {
            bool result = false;

            if (File.Exists(origem))
            {
                File.Delete(origem);
                result = true;
            }

            return result;
        }
    }
}
