﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DadosPessoais.Interfaces
{
    public interface IInvestimento
    {
        public void Aplicar(double value);
    }
}
