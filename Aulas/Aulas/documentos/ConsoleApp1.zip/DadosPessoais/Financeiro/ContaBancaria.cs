﻿using DadosPessoais.Exceptions;
using DadosPessoais.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DadosPessoais.Financeiro
{


    public class ContaBase : Auditing
    {

        public ContaBase()
        {

        }
        public ContaBase(double saldo)
        {
            this.Saldo = saldo;
        }
        public double Saldo { get; set; }

        public DateTime DataOperacao { get; set; }

        public int Conta { get; set; }
        public byte Digito { get; set; }
        public override void RegisterEntry(string entry)
        {
            throw new NotImplementedException();
        }
    }

    public class ContaBancaria : ContaBase, IContaBase, IInvestimento, IComparable<ContaBancaria>
    {
        public ContaBancaria()
        {

        }

        public ContaBancaria(string instituicao, double saldoInicial) : base(saldoInicial)
        {
            this.Instituicao = instituicao;
        }

        public string Instituicao { get; set; } = string.Empty;
        public string Agencia { get; set; } = string.Empty;
        public bool Poupanca { get; set; } = false;

        public Documentacao Documentacao { get; set; }

        public void CheckAndDebit(double saldo, DateTime operacao)
        {
            if (saldo < 0)
            {
                throw new InvalidDebitException("O valor informado para débito é inválido", saldo);
            }
            else
            {
                Debit(saldo, operacao);
            }
        }

        public void Debit(double value)
        {
            base.Saldo -= value;
        }

        public void Debit(int value)
        {
            this.Saldo -= value;
        }

        public void Debit(double value, DateTime dataOperacao)
        {
            this.Saldo -= value;
            this.DataOperacao = dataOperacao;
        }

        //Implementação explícita
        bool IContaBase.Transfer(double value, int contaDestino, byte digitoDestino)
        {
            throw new NotImplementedException();
        }

        //Implementação implícita
        public virtual bool Transfer(double value, int contaDestino, byte digitoDestino)
        {
            return true;
        }
        public void Aplicar(double value)
        {
            throw new NotImplementedException();
        }
        public override string ToString()
        {
            string resume = $"Banco: {this.Instituicao} | Conta: {base.Conta}-{base.Digito} | Saldo: {base.Saldo}";
            return resume;
        }
        public override bool Equals(object? obj)
        {
            if (obj is null)
            {
                return false;
            }

            if (obj is not ContaBancaria)
            {
                return false;
            }

            bool result = (this.Conta == ((ContaBancaria)obj).Conta && this.Digito == ((ContaBancaria)obj).Digito);
            return result;
        }

        public override int GetHashCode()
        {
            return HashCode.Combine(this.Conta, this.Digito);
        }

        public int CompareTo(ContaBancaria other)
        {
            // Se o saldo for igual então faz a ordenação numérica por conta
            if (this.Saldo == other.Saldo)
            {
                return this.Conta.CompareTo(other.Conta);
            }
            // Ordenação padrão : do maior saldo para o menor
            return other.Saldo.CompareTo(this.Saldo);
        }
    }
}
