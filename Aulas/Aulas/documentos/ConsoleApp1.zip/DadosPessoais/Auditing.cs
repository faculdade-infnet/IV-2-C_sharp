﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DadosPessoais
{

    public abstract class Auditing
    {
        public abstract void RegisterEntry(string entry);
    }
}
