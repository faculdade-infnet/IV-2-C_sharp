﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//Arquivo Utils1.cs
namespace DadosPessoais
{
    public static partial class Utils
    {
        public static bool IsValidCpf(string cpf)
        {
            // Remover formatação e verificar comprimento
            cpf = cpf.Replace(".", "").Replace("-", "");

            if (cpf.Length != 11 || !cpf.All(char.IsDigit))
                return false;

            // Verificar se todos os dígitos são iguais
            if (new string(cpf[0], 11) == cpf)
                return false;

            // Calcular primeiro dígito verificador
            int soma = 0;
            for (int i = 0; i < 9; i++)
            {
                soma += int.Parse(cpf[i].ToString()) * (10 - i);
            }
            int primeiroDigitoVerificador = (soma * 10) % 11;
            if (primeiroDigitoVerificador == 10)
                primeiroDigitoVerificador = 0;

            if (primeiroDigitoVerificador != int.Parse(cpf[9].ToString()))
                return false;

            // Calcular segundo dígito verificador
            soma = 0;
            for (int i = 0; i < 10; i++)
            {
                soma += int.Parse(cpf[i].ToString()) * (11 - i);
            }
            int segundoDigitoVerificador = (soma * 10) % 11;
            if (segundoDigitoVerificador == 10)
                segundoDigitoVerificador = 0;

            return segundoDigitoVerificador == int.Parse(cpf[10].ToString());
        }
        public static bool IsValidCnpj(string cnpj)
        {
            int[] multiplicador1 = new int[12] { 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2 };
            int[] multiplicador2 = new int[13] { 6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2 };

            cnpj = cnpj.Trim().Replace(".", "").Replace("-", "").Replace("/", "");
            if (cnpj.Length != 14)
                return false;

            string tempCnpj = cnpj.Substring(0, 12);
            int soma = 0;

            for (int i = 0; i < 12; i++)
                soma += int.Parse(tempCnpj[i].ToString()) * multiplicador1[i];

            int resto = (soma % 11);
            if (resto < 2)
                resto = 0;
            else
                resto = 11 - resto;

            string digito = resto.ToString();
            tempCnpj = tempCnpj + digito;
            soma = 0;
            for (int i = 0; i < 13; i++)
                soma += int.Parse(tempCnpj[i].ToString()) * multiplicador2[i];

            resto = (soma % 11);
            if (resto < 2)
                resto = 0;
            else
                resto = 11 - resto;

            digito = digito + resto.ToString();

            return cnpj.EndsWith(digito);
        }

        public static string ToSizeString(this long originalSize)
        {
            long KB = 1024;
            long MB = KB * 1024;
            long GB = MB * 1024;
            long TB = GB * 1024;
            double size = originalSize;

            if (originalSize >= TB)
            {
                size = Math.Round((double)originalSize / TB, 2);
                return $"{size} TB";
            }
            else if (originalSize >= GB)
            {
                size = Math.Round((double)originalSize / GB, 2);
                return $"{size} GB";
            }
            else if (originalSize >= MB)
            {
                size = Math.Round((double)originalSize / MB, 2);
                return $"{size} MB";
            }
            else if (originalSize >= KB)
            {
                size = Math.Round((double)originalSize / KB, 2);
                return $"{size} KB";
            }
            else
            {
                return $"{size} Bytes";
            }
        }
    }
}
