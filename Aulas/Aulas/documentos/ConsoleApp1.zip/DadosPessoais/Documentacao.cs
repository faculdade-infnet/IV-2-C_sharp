﻿
//public struct Documentacao
//{

//    public Documentacao()
//    {
//        this.CPF = string.Empty;
//        this.RG = string.Empty;
//    }

//    public string CPF { get; set; }

//    public string RG { get; set; }

//    public override string ToString()
//    {
//        return $"{this.RG}-{this.CPF}";
//    }
//}

//public readonly struct Documentacao
//{

//    public Documentacao(string cpf, string rg)
//    {
//        this.CPF = cpf;
//        this.RG = rg;
//    }

//    public readonly string CPF { get; init; }

//    public readonly string RG { get; init; }

//    public override string ToString()
//    {
//        return $"{this.RG}-{this.CPF}";
//    }
//}

public record Documentacao(string RG)
{
    public string CPF { get; set; } = string.Empty;
}