﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//Arquivo Utils.cs
namespace DadosPessoais
{


    public static partial class Utils
    {
        static readonly int accountDigitsSize;
        static Utils()
        {
            accountDigitsSize = 4;
        }
        public static int CreateAccountNumber()
        {
            int maxNumber = int.Parse(new String('9', accountDigitsSize));
            Random rnd = new Random();
            int accountNumber = rnd.Next(0001, maxNumber);

            return accountNumber;
        }
        public static byte CreateAccountDigit()
        {
            Random rnd = new Random();
            byte accountDigit = Convert.ToByte(rnd.Next(1, 9));

            return accountDigit;
        }
        public static bool IsValidAccount(this int account, int newType)
        {
            string sanitized = account.ToString().PadLeft(4, '0');
            return sanitized.Length == 4;
        }
    }
}
