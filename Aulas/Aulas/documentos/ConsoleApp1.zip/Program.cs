﻿using ConsoleApp1.Suporte;
using DadosPessoais;
using DadosPessoais.Exceptions;
using DadosPessoais.Financeiro;
using DadosPessoais.Interfaces;
using System.ComponentModel;
using System.IO;
using System.IO.Compression;
using System.Text;
using System.Xml.Linq;
using System.Xml.Serialization;

namespace ConsoleApp1
{
    internal class Program
    {

        static void Main(string[] args)
        {
            int[] validDigits = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 0 };
            int[] faixa1 = validDigits[Range.StartAt(3)];
            int[] faixa2 = validDigits[new Range(5, 8)];

            Console.WriteLine($"Elementos na faixa 1: {string.Join(",", faixa1)}");
            Console.WriteLine($"Elementos na faixa 2: {string.Join(",", faixa2)}");
            Console.Read();
        }
        //static void Main(string[] args)
        //{
        //    Documentacao contaId = new("212");
        //    contaId.CPF = "009";

        //    Documentacao contaDoc = contaId with { RG = "353" };

        //    ContaBancaria conta = new("CEF", 700)
        //    {
        //        Agencia = "18",
        //        Conta = Utils.CreateAccountNumber(),
        //        Digito = Utils.CreateAccountDigit(),
        //        Documentacao = contaDoc
        //    };

        //    Console.WriteLine($"Cliente: {conta.Documentacao.RG}-{conta.Documentacao.CPF}");
        //    Console.WriteLine($"Documentação: {contaDoc.ToString()}");
        //    Console.Read();
        //}




        //static void Main(string[] args)
        //{
        //    DateTime operacao = DateTime.Now;

        //    ContaBancaria conta = new("CEF", 700)
        //    {
        //        Agencia = "18",
        //        Conta = Utils.CreateAccountNumber(),
        //        Digito = Utils.CreateAccountDigit()
        //    };

        //    ContaBancaria contaAdicional = new("CEF", 2300)
        //    {
        //        Agencia = "18",
        //        Conta = Utils.CreateAccountNumber(),
        //        Digito = Utils.CreateAccountDigit()
        //    };

        //    ContaBancaria contaExtra = new("CEF", 200)
        //    {
        //        Agencia = "18",
        //        Conta = Utils.CreateAccountNumber(),
        //        Digito = Utils.CreateAccountDigit()
        //    };

        //    List<ContaBancaria> contas = new();
        //    contas.Add(conta);
        //    contas.Add(contaAdicional);
        //    contas.Add(contaExtra);
        //    contas.Sort();

        //    foreach (ContaBancaria item in contas)
        //    {
        //        Console.WriteLine($"Conta: {item.Conta}-{item.Digito} | Saldo: {item.Saldo}");
        //    }

        //    Console.Read();
        //}


    }
}
