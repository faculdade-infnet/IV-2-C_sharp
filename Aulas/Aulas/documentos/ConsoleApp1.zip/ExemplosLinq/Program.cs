﻿namespace ExemplosLinq
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<Pessoa> pessoas = new()
            { 
                new() { Nome = "Juca", SobreNome = "Bala", Cpf = "001.001.001-99", Idade = 39},
                new() { Nome = "Tião", SobreNome = "Veneno", Cpf = "007.007.007-91", Idade = 43},
                new() { Nome = "Jussara", SobreNome = "Chumbinho", Cpf = "004.004.004-88", Idade = 37},
                new() { Nome = "Fulgêncio", SobreNome = "Fogueira", Cpf = "009.008.007-81", Idade = 37}
            };

            var result = from p in pessoas
                         where p.Idade > 35
                         orderby p.Idade, p.Nome
                         select p;

            foreach (Pessoa i in result)
            {
                Console.WriteLine($"Nome: {i.Nome} / Idade: {i.Idade}");
            }

            Console.ReadLine();
        }
    }
}
