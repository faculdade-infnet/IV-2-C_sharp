﻿namespace DelegApp
{
    internal class Program
    {
        public delegate void TesteDelegate();
        public delegate void TesteDelegateParameter(string blah);

        static void Main(string[] args)
        {
            Console.WriteLine($"{new string('-', 20)}Delegates primários {new string('-', 20)}");
            TesteDelegate simplesDelegate = new TesteDelegate(ProcessarTexto);
            TesteDelegateParameter parameterDelegate = new TesteDelegateParameter(ProcessarParametro);
            TesteDelegateParameter outroParameterDelegate = new TesteDelegateParameter(OutroProcessarParametro);

            simplesDelegate();
            parameterDelegate("Método com parâmetro chamado por delegate");
            outroParameterDelegate("Método diferente com parâmetro, chamado por delegate");
            Console.WriteLine($"{new string('-', 20)}Fim Delegates primários {new string('-', 20)}");

            Console.WriteLine();

            Console.WriteLine($"{new string('-', 20)}Delegates por Func {new string('-', 20)}");
            Func<double, double, double> Calcular = Adicionar;
            double resultadoSoma = Calcular(9, 9);
            Console.WriteLine("Delegate: " + resultadoSoma);
            Console.WriteLine($"{new string('-', 20)}Fim Delegates por Func {new string('-', 20)}");

            Console.WriteLine();

            Console.WriteLine($"{new string('-', 20)}Delegates por Func anônimo {new string('-', 20)}");
            Func<double, double, double> CalcularAnonimo = delegate (double n1, double n2)
            {
                return n1 + n2;
            };

            double resultadoSoma2 = CalcularAnonimo(1, 9);
            Console.WriteLine("Delegate anônimo: " + resultadoSoma2);
            Console.WriteLine($"{new string('-', 20)}Fim Delegates por Func anônimo {new string('-', 20)}");

            Console.ReadKey();
        }

        public static void ProcessarTexto()
        {
            Console.WriteLine("Método chamado através de delegate");
        }

        public static void ProcessarParametro(string blah)
        {
            Console.WriteLine(blah);
        }

        public static void OutroProcessarParametro(string blah)
        {
            Console.WriteLine(blah);
        }

        private static double Adicionar(double n1, double n2)
        {
            return n1 + n2;
        }
    }
}
